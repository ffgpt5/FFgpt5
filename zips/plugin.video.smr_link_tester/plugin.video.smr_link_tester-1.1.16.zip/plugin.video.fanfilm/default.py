"""
    FanFilm Add-on
    Copyright (C) 2025 - original author MrKnow

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""
from kover import autoinstall  # noqa: F401

# --- ABOUT POPUP ---
def show_about():
    import os, xbmc, xbmcgui, xbmcaddon
    addon = xbmcaddon.Addon()
    about_path = os.path.join(addon.getAddonInfo('path'), 'resources', 'about.txt')
    try:
        with open(about_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        content = 'Brak pliku about.txt w resources/ lub błąd odczytu: %s' % e
    xbmcgui.Dialog().textviewer('FanFilm – opis działania', content)

from ptw.libraries import control

import xbmcaddon
control.setting = xbmcaddon.Addon().getSetting
control.setSetting = xbmcaddon.Addon().setSetting

if control.setting("additional_working_info") == "true" or (control.infoLabel('Container.FolderPath')).startswith("plugin://plugin.video.themoviedb.helper/"):
    if not control.condVisibility('Window.IsActive(notification)'):
        control.infoDialog('', time=1, sound=False)
        control.sleep(100)
        pass  # aby móc łatwo zakomentować powyższą linijkę


from contextlib import contextmanager
from urllib.parse import parse_qsl, urlencode
import sys


#control.setSetting('appearance.1', 'Incursion')  # już niepotrzebne


FFlastpath = control.window.getProperty('FanFilm.var.lastpath')  # z pamięci
FFlastpath = eval(FFlastpath) if FFlastpath else {}  # tylko jak Kodi wczytuje folder z cachu, to ta zmienna się nie zmienia (bo plugin nie jest wywoływany)

prev_lastpath = control.window.getProperty('FanFilm.var.prev_lastpath')
prev_lastpath = eval(prev_lastpath) if prev_lastpath else {}

folderpath  = control.infoLabel('Container.FolderPath')
KFolderPath = dict(parse_qsl(folderpath.split('?')[-1]))  # taki niby referer, ale nie działa prawidłowo, jak odpalamy z widgetu

currentPath = dict(parse_qsl(sys.argv[2][1:]))
#control.log(f"{currentPath=}", 1)

referer = KFolderPath if KFolderPath != currentPath else ''
# control.log(f'{referer=} ', 1)


generate_short_path = control.setting("generate_short_path") == "true"

logsilent = control.setting("logsilent") == "true"

# for debug
if False and currentPath.get("action") not in ["service", "libepisodesservice"]:

    control.log(f"\n\n________________________________________________________________ ", 1)

    control.log(f"{control.infoLabel('Container.PluginName')=}", 1)  # może się przydać (użyte w sources.py do detekcji czy ma być katalog czy okienko) (chyba puste, gdy odpalamy pozycje z biblioteki)
    control.log(f" ", 1)

    control.log(f" {FFlastpath=}", 1)
    control.log(f"{KFolderPath=}  ({folderpath.split('?')[0]})", 1)
    control.log(f"{currentPath=}", 1)
    control.log(f'    {referer=} ', 1)
    control.log(f" ", 1)

    # https://alwinesch.github.io/modules__infolabels_boolean_conditions.html
    control.log(f"{control.infoLabel('Container.FolderPath')=}", 1)
    control.log(f" {control.infoLabel('ListItem.FolderPath')=}", 1)
    control.log(f" {control.infoLabel('ListItem.Path')=}", 1)
    control.log(f'{control.infoLabel("ListItem.FileNameAndPath")=}', 1)
    control.log(f'{control.infoLabel("ListItem.FileName")=}', 1)
    control.log(f" ", 1)

    control.log(f'{control.infoLabel("Container.NumPages")=}', 1)
    control.log(f'{control.infoLabel("Container.CurrentPage")=}', 1)
    control.log(f'{control.infoLabel("Container.NumItems")=}', 1)
    control.log(f'{control.infoLabel("Container.NumAllItems")=}', 1)
    control.log(f" ", 1)
    control.log(f'{control.infoLabel("Container.CurrentItem")=}', 1)
    control.log(f'{control.infoLabel("ListItem.CurrentItem")=}', 1)
    control.log(f'{control.infoLabel("ListItem.FileNameAndPath")=}', 1)
    control.log(f"{control.infoLabel('ListItem.Label')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Label2')=}", 1)

    control.log(f" ", 1)
    control.log(f"{control.infoLabel('ListItem.Title')=}", 1)
    control.log(f"{control.infoLabel('ListItem.OriginalTitle')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(englishTitle)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.TvShowTitle')=}", 1)
    control.log(f"{control.infoLabel('Container.showtitle')=}", 1)  # nie wiem kiedy to ma działać
    control.log(f"{control.infoLabel('ListItem.Property(englishTvShowTitle)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(OriginalTvShowTitle)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.UniqueID(imdb)')=}", 1)  # od Kodi 19 ?
    control.log(f"{control.infoLabel('ListItem.UniqueID(tmdb)')=}", 1)  # od Kodi 19 ?
    control.log(f"{control.infoLabel('ListItem.UniqueID(tvdb)')=}", 1)  # od Kodi 19 ?
    control.log(f"{control.infoLabel('ListItem.Property(imdb_id)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(tmdb_id)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(tvdb_id)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(meta)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Season')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Episode')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Premiered')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Year')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(TvShowYear)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Country')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Plot')=}", 1)
    control.log(f"{control.infoLabel('ListItem.MPAA')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Duration')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Overlay')=}", 1)
    control.log(f"{control.infoLabel('ListItem.PlayCount')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Votes')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(Popularity)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(TotalSeasons)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(TotalEpisodes)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(fullpath)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(url)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Property(IsPlayable)')=}", 1)
    #control.log(f"{control.infoLabel('ListItem.IsFolder')=}", 1)  # źle, bo to jest typu bool
    control.log(f"{control.condVisibility('ListItem.IsFolder')=}", 1)  # to jest poprawne
    #control.log(f"{control.infoLabel('ListItem.Thumb')=}", 1)  #  Deprecated but still available, returns the same as ListItem.Art(thumb).
    #control.log(f"{control.infoLabel('ListItem.Icon')=}", 1)
    # control.log(f"{control.infoLabel('ListItem.ActualIcon')=}", 1)
    control.log(f"{control.infoLabel('ListItem.DBID')=}", 1)
    control.log(f"{control.infoLabel('ListItem.DBTYPE')=}", 1)
    
    control.log(f"{control.infoLabel('ListItem.Thumb')=}", 1)  # Deprecated but still available, returns the same as ListItem.Art(thumb).
    control.log(f"{control.infoLabel('ListItem.Art(thumb)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(poster)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.poster)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(tvshow.poster)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(banner)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(clearlogo)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(clearart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(fanart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(landscape)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(keyart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(discart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(characterart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(dupa)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Icon')=}", 1)
    control.log(f"{control.infoLabel('ListItem.ActualIcon')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.banner)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.landscape)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(tvshow.banner)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(tvshow.clearlogo)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(tvshow.fanart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.fanart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.clearlogo)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.clearart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.keyart)')=}", 1)
    control.log(f"{control.infoLabel('ListItem.Art(season.icon)')=}", 1)
    control.log(f" ", 1)

    # to coś nie działa, albo dziwnie działa
    #control.log(f"{control.window.getProperty('LatestMovie.1.Title')=}", 1)
    #control.log(f"{control.infoLabel('Window(Home).Property(LatestMovie.1.Title)')=}", 1)
    #control.log(f" ", 1)

    control.log(f"{control.infoLabel('Container.Content')=}", 1)

    control.log(f"{control.infoLabel('Window.Property(xmlfile)')=}", 1)

    control.log(f"{control.infoLabel('System.CurrentWindow')=}", 1)
    control.log(f"{control.infoLabel('System.CurrentControl')=}", 1)
    control.log(f"{control.infoLabel('System.CurrentControlID')=}", 1)

    # import xbmcgui
    # win_id = xbmcgui.getCurrentWindowId()
    win_id = control.currentWindowId
    control.log(f"{win_id=}", 1)

    # focus_panel_id = control.getCurrentViewId()
    # control.log(f"{focus_panel_id=}", 1)

    if 0:
        # import xbmc
        # xbmc.executebuiltin('SetFocus(9000,14000)')
        # https://kodi.wiki/view/List_of_built-in_functions#GUI_control_built-in's
        # https://xbmc.github.io/docs.kodi.tv/master/kodi-base/d0/d3e/page__list_of_built_in_functions.html#built_in_functions_7
        # xbmc.executebuiltin('Control.Message(50,moveup)')
        # xbmc.executebuiltin('Control.Move(50,1)')
        # xbmc.executebuiltin('SetFocus(50,2,absolute)')
        control.execute(f'SetFocus({focus_panel_id},2,absolute)')
        control.sleep(200)
        control.log(f"{control.infoLabel('ListItem.Label')=}", 1)


    #control.log(f"{control.condVisibility('Window.IsVisible(DialogVideoInfo.xml)')=}", 1)
    #control.log(f"{control.condVisibility('Window.IsVisible(DialogBusy.xml)')=}", 1)

    control.log(f" ", 1)


handle = int(sys.argv[1])

params = dict(parse_qsl(sys.argv[2].replace("?", "")))

control.log(f'\n[FanFilm][default.py] początek {params=}', 0)

action = params.get("action")

name = params.get("name")
title = params.get("title")
localtitle = params.get("localtitle") or params.get("title")
year = params.get("year")
imdb = params.get("imdb")
tmdb = params.get("tmdb")
tvdb = params.get("tvdb")
tvshowtitle = params.get("tvshowtitle")
season = params.get("season")
episode = params.get("episode")
url = params.get("url")



def przekierowanie(url2, item=None, replace=1):  # nie wiem, czy nie lepiej zrobić domyślnie replace=0
    url2 = sys.argv[0] + url2
    # control.log(f'[FanFilm] [przekierowanie] {url2=}',1)
    if handle > -1:
        url2 +='&r=1' if '&r=1' not in url2 else ''  # aby nie pytał ponownie
        if item:
            # control.addItem(handle, sys.argv[0]+"?action=nothing", item, False)  # opcjonalnie do odświeżenia, ale tu mi potrzebne gdy generate_short_path 
            control.addItem(handle, url2, item, True)  # opcjonalnie do odświeżenia, ale tu mi potrzebne gdy generate_short_path 
        control.directory(handle, cacheToDisc=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
        control.sleep0(100)  # potrzebne jakieś drobne opóźnienie, bo czasami nie chce się uruchomić przekierowanie
        control.log("[FanFilm] [przekierowanie] przekierowanie (odświeżenie)", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
        # control.execute('Container.Update('+ url2 +')')
        control.update(url2, replace=replace)
    else:
        control.log(f'[FanFilm] [przekierowanie] {handle=}',1)
        control.update(url2, replace=replace)
        # if replace:
            # control.execute("Container.Update(%s, replace)" % url2)
        # else:
            # control.execute("Container.Update(%s)" % url2)
    global action
    action = "nothing"


def obsluga_wyboru_strony(url, total_pages):
    page = params.get("page")
    if not page:
        page = dict(parse_qsl(url))
        page = page.get("page")
        # control.log(f'[FanFilm] [obsluga_wyboru_strony] {page=}',1)
    if not page:
        return action
    # curr_page = params.get("curr_page")
    import xbmcgui
    while True:
        s = xbmcgui.Dialog().input(f"wpisz numer strony\n(0 - {total_pages})", type=xbmcgui.INPUT_NUMERIC)
        if not s or 0 <= int(s) <= int(total_pages):
            break
        if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić? \n[COLOR gray]dozwolony zakres to 1-{total_pages}[/COLOR]")):
            s = ''
            break
    if s:
        item = None
        url2 = ""
        if s != "0":
            params.update({"page": s})
            page = s
            # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
            import re
            url = re.sub("((?<=[?/])|&)(page|total_pages|curr_page)[=/][^&]*", "", url).replace("?&", "?").rstrip("?&")
            # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
            if page and "page" not in url:
                q_or_a = "&" if "?" in url else "?"
                url += f"{q_or_a}page={page}"
            # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url=}',1)
            params.update({ "url": url })
            params.pop("total_pages", None)
            params.pop("curr_page", None)
            if params.get("targetAction"):
                params.update({ "action": params.get("targetAction") })
                params.pop("targetAction", None)
            url2 = '?' + urlencode(params)
            # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url2=}',1)
            item = control.item(" trwa zmiana ... ")
            if generate_short_path:
                url2 = re.sub("((?<=[?/])|&)(url)[=/][^&]*", "", url2).replace("?&", "?").rstrip("?&")
                # control.log(f'[FanFilm] [obsluga_wyboru_strony] {url2=}',1)
                if control.infoLabel('ListItem.Property(urlDNext)'):
                    # control.log(f'[FanFilm] [obsluga_wyboru_strony] urlDNext (property)',1)
                    item.setProperty("urlDNext", url2)
                else:
                    # control.log(f'[FanFilm] [obsluga_wyboru_strony] url (property)',1)
                    item.setProperty("url", url2)
        else:
            pass  # jeszcze nie wiem co zrobić
            control.log(f'[FanFilm] [obsluga_wyboru_strony] {s=}',1)
        if url2:
            przekierowanie(url2, item, 0)
            action = "nothing"
        else:
            return "BackToMain|" + globals()["action"]
    else:
        action = ""
    return action



if not action:
    control.log("[FanFilm] start default action", not(logsilent))

    resolverCheck = control.setting("resolverCheck")
    ptwCheck = control.setting("ptwCheck")

    if ptwCheck == "true":
        control.log("[FanFilm] checking PTW version", not(logsilent))
        from checker import PtwModuleChecker
        PtwModuleChecker().checkVersion()

    if resolverCheck == "true":
        control.log("[FanFilm] checking ResolveUrl version", not(logsilent))
        from checker import ResolveUrlChecker
        ResolveUrlChecker().checkVersion()

    control.log("[FanFilm] preparing Menu", not(logsilent))
    from resources.lib.indexers import navigator
    navigator.navigator().root()
    control.log("[FanFilm] Menu is ready", not(logsilent))

    control.window.clearProperty('FanFilm.var.curr_item_p')  # tylko, że to nie zawsze się wykona


elif action == "play":
    premiered = params.get("premiered")
    meta = params.get("meta")
    select = params.get("select")
    originalname = params.get("originalname", "")
    epimdb = params.get("epimdb", "")
    customTitles = params.get("customTitles")
    #mediatype = params.get("mediatype", "")  # może potem będzie zbędne (może season i episode wystarczy)

    if not params.get("title"):
        title = control.infoLabel('ListItem.Property(englishTitle)')
        title = control.infoLabel('ListItem.OriginalTitle') if not title else title

    if not params.get("localtitle"):
        localtitle = control.infoLabel('ListItem.Title')

    if not params.get("tvshowtitle"):
        tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
        tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
        tvshowtitle = tvshowtitle if tvshowtitle else None

    if not params.get("year"):
        year = control.infoLabel('ListItem.Property(TvShowYear)')
        year = control.infoLabel('ListItem.Year') if not year else year

    if not params.get("imdb"):
        imdb = control.infoLabel('ListItem.Property(imdb_id)')  # starsze Kodi ( < 20)
        imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb
        imdb = imdb if imdb else None

    if not params.get("tmdb"):
        tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
        tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
        tmdb = tmdb if tmdb else None

    if not params.get("tvdb"):
        tvdb = control.infoLabel('ListItem.Property(tvdb_id)')  # starsze Kodi ( < 20)
        tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb
        tvdb = tvdb if tvdb else None

    if not params.get("meta"):
        meta = control.infoLabel('ListItem.Property(meta)')
        meta = meta if meta else None

    if not params.get("season"):
        season = control.infoLabel('ListItem.Season')
        season = season if season else None

    if not params.get("episode"):
        episode = control.infoLabel('ListItem.Episode')
        episode = episode if episode else None

    if not params.get("premiered"):
        premiered = control.infoLabel('ListItem.Premiered')

    # wykrycie, czy wywołanie jest z zewnątrz
    # obcy = not control.infoLabel("ListItem.CurrentItem")  # nie sprawdził się przy refresh
    obcy = control.infoLabel("Container.NumPages")  # moze też być CurrentPage, NumItems, NumAllItems
    # startowa = True if obcy == "" else False  # może 'Container.PluginName' by wystarczył - trzeba potestować
    obcy = not int(obcy) if obcy else False
    # control.log(f'{obcy=}', 1)
    # nie sprawdza się do końca
    # próba korekty tej zmiennej
    if FFlastpath.get("action") == "playItem":  # nie wiem, czy nie trzeba też dołożyć "showItems"
        obcy = False
        # control.log(f'{obcy=}', 1)
    # ale powyjściu z wygaszacza pokazuje, że obcy, a akcja to play
    # control.log(f'{tmdb=}', 1)
    if (
        params.get("r")
        or not obcy and tmdb is None
        or tmdb is None and KFolderPath == currentPath
        or tmdb is None and FFlastpath == currentPath  # to może pomóc
        ):
        # control.log(f'z pamieci', 1)
        zmienne = control.window.getProperty('FanFilm.var.curr_item_p')  # z pamięci
        # control.log(f'{zmienne=}', 1)
        if zmienne:
            zmienne = eval(zmienne)
            globals().update(zmienne)  # opcjonalnie
    else:
        # control.log(f'do pamieci', 1)
        #zmienne = (title, localtitle, year, imdb, tvdb, tmdb, season, episode, tvshowtitle, premiered, meta, select, customTitles, originalname, epimdb)
        zmienne = {"title":title, "localtitle":localtitle, "year":year, "imdb":imdb, "tvdb":tvdb, "tmdb":tmdb,
                   "season":season, "episode":episode, "tvshowtitle":tvshowtitle, "premiered":premiered,
                   "meta":meta, "select":select, "originalname":originalname, "epimdb":epimdb}
        control.window.setProperty('FanFilm.var.curr_item_p', repr(zmienne))  # do pamięci

    # control.log(f' [ KONTROLA ] \n{title=} \n{localtitle=} \n{year=} \n{imdb=} \n{tvdb=} \n{tmdb=} \n{season=} \n{episode=} \n{tvshowtitle=} \n{premiered=} \n{meta=} \n{select=} \n{customTitles=} \n{originalname=}  \n{epimdb=}', 1)
    #control.log(f" {control.window.getProperty('imdb_id')=}", 1)

    folderpath = control.infoLabel('Container.FolderPath')
    select = control.setting("hosts.mode") if select is None else select
    # control.log(f"{select=}", 1)
    # if select == "1" and folderpath.startswith("plugin://plugin.video.themoviedb.helper/"):  # może dałoby się zrobić bardziej uniwersalnie ?
    #if select == "1" and not control.infoLabel("Container.PluginName"):  # próba uniwersalności
    if select == "1" and "plugin.video.fanfilm" not in control.infoLabel("Container.PluginName"):  # próba uniwersalności
        select = "0"
    #elif select == "0" and handle > 0 and not folderpath.startswith("plugin://plugin.video.themoviedb.helper/"):
    #elif select == "0" and handle > 0 and control.infoLabel("Container.PluginName") and not control.infoLabel("ListItem.FolderPath"):
    elif (select == "0" or select == "2") and handle >= 0 and control.infoLabel("Container.PluginName") and not control.infoLabel("ListItem.FolderPath"):
        select = "1"  # pomaga wyświetlać katalogi, gdy user ustawił okienko  # tu nie, aby nie robić przekierowania (szkoda), bo warunki się zmieniają (te 2 na końcu), ale sources.py już to ustawia
        pass
        control.log(f'{control.infoLabel("Container.PluginName")=}', 0)
        control.log(f'{control.infoLabel("ListItem.FolderPath")=}', 0)
    # control.log(f"{select=}", 1)

    # powyższa ewentualna zmiana select chyba tylko potrzebna do warunku kolejnej linijki

    # if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
    if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r") and control.infoLabel("Container.PluginName"):
        if KFolderPath.get("r"):
            control.log("aby nie powstała nieskończona pętla", not(logsilent))
            control.directory(handle, cacheToDisc=False)  # obowiązkowo
            control.log("akcja wstecz", not(logsilent))
            control.execute('Action(Back)')
            action = "nothing"
        else:
            control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
            """
            import json
            try:
                meta = json.loads(meta)
            except:
                meta = {}
            for k,v in params.items():
                if k not in ["meta", "action"]:
                #if k not in zmienne:
                    meta.update({k: v})

            # są potrzebne korekty pod FF
            if (val := meta.get("localtitle")):
                meta.update({"title": val}); meta.pop('localtitle')
            if (val := meta.get("localtvshowtitle")):
                meta.update({"tvshowtitle": val}); meta.pop('localtvshowtitle')
            # jeszce potrzeba korekt na thumb i poster

            meta = json.dumps(meta)
            zmienne.update({"meta": meta})
            control.window.setProperty('FanFilm.var.curr_item_p', repr(zmienne))  # do pamięci jeszcze raz
            """
            #sign = "-" if not control.infoLabel("ListItem.FolderPath") else ""  # to nic nie dało
            # control.addItem(handle, sys.argv[0]+"?action=play&r=1", control.item(" proszę czekać ..."), True)  # opcjonalnie
            control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
            control.directory(handle, cacheToDisc=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
            control.sleep0(100)
            control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
            control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')
            action = "nothing"
    else:
        if select == "0":
            control.busy()
            control.sleep(500)

        from ptw.libraries import sources
        if customTitles:
            if zmienne:
                zmienne.update({"customTitles": customTitles})
            sources.sources().alterSources(zmienne)
        else:
            #sources.sources().play(title, localtitle, year, imdb, tvdb, tmdb, season, episode, tvshowtitle, premiered, meta, select, originalname=originalname, epimdb=epimdb)
            if zmienne:
                #sources.sources().play(*zmienne)
                sources.sources().play(**zmienne)

        if select == "0":
            control.idle(2)
            pass


elif action == "showItems":
    if not (title := params.get("title")):    
        # title = control.infoLabel('ListItem.OriginalTitle')
        title = control.infoLabel('ListItem.Property(title)')
        if title:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.title', title)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            title = control.window.getProperty('FanFilm.var.title')  # z pamięci
    #control.log(f"{title=}", 1)
    from ptw.libraries import sources
    sources.sources().showItems(title, params.get("items"), params.get("trash"), season, episode)


elif action == "playItem":
    title = params.get("title") or control.infoLabel('ListItem.Title') or None
    source = params.get("source") or control.infoLabel('ListItem.Property(source)') or None
    meta = params.get("meta") or control.infoLabel('ListItem.Property(meta)') or None
    auto_select_next_item_to_play = params.get("auto_select_next_item_to_play")

    from ptw.libraries import sources
    sources.sources().playItem(title, source, meta, imdb, tmdb, season, episode, auto_select_next_item_to_play=auto_select_next_item_to_play)


elif action == "movieNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().movies()


elif action == "movieliteNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().movies(lite=True)


elif action == "mymovieNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().mymovies()


elif action == "mymovieliteNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().mymovies(lite=True)


elif action == "tvNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().tvshows()


elif action == "tvliteNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().tvshows(lite=True)


elif action == "mytvNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().mytvshows()


elif action == "downloadNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().downloads()


elif action == "libraryNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().library()


elif action == "toolNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().tools()


elif action == "about":
    show_about()


elif action == "searchNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().search()


elif action == "viewsNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().views()


elif action == "cacheNavigator":
    from resources.lib.indexers import navigator
    navigator.navigator().cache()


elif action == "clearLibCache":
    from resources.lib.indexers import navigator
    navigator.navigator().clearLibCache()


elif action == "clearCache":
    from resources.lib.indexers import navigator
    navigator.navigator().clearCache()


elif action == "clearCacheMeta":
    from resources.lib.indexers import navigator
    navigator.navigator().clearCacheMeta()


elif action == "clearCacheProviders":
    from resources.lib.indexers import navigator
    navigator.navigator().clearCacheProviders()


elif action == "clearCacheSearch":
    from resources.lib.indexers import navigator
    if navigator.navigator().clearCacheSearch(params.get("content")) is not False:
        control.refresh()


elif action == "removeFromSearchHistory":
    from resources.lib.indexers import navigator
    if navigator.navigator().removeFromSearchHistory(params.get("term"), params.get("content")) is not False:
        control.refresh()

        
elif action == "clearCacheAll":
    from resources.lib.indexers import navigator
    navigator.navigator().clearCacheAll()


elif action == "clearCacheAllSilent":
    from resources.lib.indexers import navigator
    navigator.navigator().clearCacheAllSilent()


elif action == "infoCheck":
    from resources.lib.indexers import navigator
    navigator.navigator().infoCheck("")


elif action == "downloadManager":
    from ptw.libraries import downloader
    downloader.downloadManager()
    # after close modal window
    if not control.monitor.abortRequested():
        control.sleep(500)  # because of animation
        # handle = int(sys.argv[1])
        if handle > -1:
            control.directory(handle, cacheToDisc=False)
            control.log(f"akcja wstecz (po {action})", 0)
            control.execute('Action(Back)')
            action = "nothing"


# elif action == "movies" or action == "moviePage" or action == "multiPage" or action == "multi" or action == "collections":
elif action in ["movies", "moviePage", "multiPage", "multi", "collections", "collectionsPage"]:
    # control.log(f'{KFolderPath=}\n{FFlastpath=}\n{currentPath=}\n{referer=}\n{prev_lastpath=}',1)
    if not url:
        if "collectionsPage" in action:
            url = control.infoLabel('ListItem.Property(urlDNext)')
            nxt = ".next"
        else:
            url = control.infoLabel('ListItem.Property(url)')
            nxt = ""
        if url:
            # control.log(f'do pamieci {url=}', 1)
            control.window.setProperty('FanFilm.var.url'+nxt, url)  # do pamięci
        else:
            url = control.window.getProperty('FanFilm.var.url'+nxt)  # z pamięci
            # control.log(f'z pamieci {url=}', 1)
        if nxt:
            import re
            control.log(f'{nxt=} {page=}',1)
            url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
        page = params.get("page")
        # control.log(f'{page=}',1)
        if generate_short_path:
            if referer and referer.get("page") or not referer and prev_lastpath and prev_lastpath.get("page"):
                page = page or 1  # to nie zawsze jest dobrze, bo np. dla list trakt
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
    # control.log(f'{action=} {url=}', 1)
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            refresh = params.get("refresh")
            category = dict(parse_qsl(url)).get("query") or ""
            # control.log(f'{action=} {category=}', 1)
            if not category:
                item = params.get("item") or ""
                # from urllib.parse import unquote
                # item = unquote(item)
                try:
                    category = item  if not item.isnumeric() or 1900 <= int(item) <= 2999  else ""
                except:
                    pass
                # control.log(f'{action=} {category=}', 1)
            from resources.lib.indexers import movies
            if "multi" in action:
                movies.movies().multi(url, refresh=refresh, category=category)
            elif "collectionsPage" in action:
                # movies.movies().collections(url, category=category)
                movies.movies().collections(url, category=["Kolekcje", category])
            else:
                movies.movies().get(url, refresh=refresh, category=category)
        else:
            # from resources.lib.indexers import movies
            if "multi" in action:
                pass
                przekierowanie("?action=multiSearch")
            elif "collectionsPage" in action:
                pass
                #movies.movies().search("collection", "Kolekcje")  # tak nie, pod pod adresem kolejnej podstrony będzie inna zawartość
                przekierowanie("?action=collectionSearch")
            else:
                pass
                przekierowanie("?action=movieNavigator")
            action = "nothing"


elif action == "movieWidget":
    from resources.lib.indexers import movies
    movies.movies().widget()


elif action == "personSearch":
    control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
    from resources.lib.indexers import movies
    movies.movies().search(s_type="person", category="Osoby")


elif action == "personSearchnew":
    from resources.lib.indexers import movies
    movies.movies().search_new(s_type="person")


elif action == "multiSearch":
    control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
    from resources.lib.indexers import movies
    movies.movies().search(s_type="multi", category="Filmy i seriale")


elif action == "multiSearchnew":
    from resources.lib.indexers import movies
    movies.movies().search_new(s_type="multi")


elif action == "collectionSearch":
    control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
    from resources.lib.indexers import movies
    # movies.movies().search(s_type="collection", category="Kolekcje")
    movies.movies().search("collection", "Kolekcje")


elif action == "collectionSearchnew":
    from resources.lib.indexers import movies
    movies.movies().search_new(s_type="collection")


elif action == "movieSearch":
    control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
    from resources.lib.indexers import movies
    movies.movies().search(category="Filmy")


elif action == "movieSearchnew":
    from resources.lib.indexers import movies
    movies.movies().search_new()


# elif action == "movieSearchterm" or action == "personSearchterm" or action == "multiSearchterm" or action == "collectionSearchterm":
elif action in ["movieSearchterm", "personSearchterm", "multiSearchterm", "collectionSearchterm"]:
    if not params.get("name"):
        folderpath = control.infoLabel('Container.FolderPath') 
        referer = dict(parse_qsl(folderpath.split('?')[-1]))
        # if referer.get("action") == "movieSearch":
        if referer.get("action") in ["movieSearch", "personSearch", "multiSearch", "collectionSearch"]:
            name = control.infoLabel('ListItem().Label')  # z wybranej pozycji
            control.window.setProperty('FanFilm.var.name', name)  # do pamięci
            # control.log(f'do pamieci', 1)
        else:
            name = control.window.getProperty('FanFilm.var.name')  # z pamięci
            # control.log(f'z pamieci', 1)
    from resources.lib.indexers import movies
    if action == "movieSearchterm":
        movies.movies().search_term(name)
    elif action == "personSearchterm":
        movies.movies().search_term(name, s_type="person")
    elif action == "multiSearchterm":
        movies.movies().search_term(name, s_type="multi")
    elif action == "collectionSearchterm":
        movies.movies().search_term(name, s_type="collection")


elif action == "movieSearchEPG":
    if not name:
        import re
        label = control.infoLabel('ListItem().Label')
        # control.log(f'{label=}',1)
        name = re.search(r"^(.+?)(?= \[)", label)
        name = name[0] if name else label
        # control.log(f'{label=}',1)
        # control.log(f'{params=}',1)
        if not params.get("year"):
            year = re.search(r"(?<=\[I\]\()\d{4}(?=r\.\)\[/I\])", label)
            year = year[0] if year else control.infoLabel('ListItem().Year')
        else:
            year = ""
        # control.log(f'{action=} {name=} {year=}', 1)
    if name and name != "..":
        from resources.lib.indexers import movies
        movies.movies().search_epg(name, year)
    else:
        # bo nie zachowałem w pamięci
        control.directory(handle, cacheToDisc=False)  # obowiązkowo
        control.execute('Action(Back)')
        action = "nothing"
        pass


elif action == "prepareItemForAddToLibrary":
    item = {}
    item.update({"fullpath": control.infoLabel('ListItem.Property(fullpath)')})
    if item.get("fullpath"):
        item.update({"label": control.infoLabel('ListItem.Label')})
        item.update({"icon": control.infoLabel('ListItem.Icon')})
        item.update({"year": control.infoLabel('ListItem.Year')})
        #from resources.lib.indexers import movies
        #movies.movies().prepareItemForAddToLibrary([item])
        items = [item]  # dla komatybilności na razie zrobiłem
        # syshandle = int(sys.argv[1])
        addonFanart, addonThumb, artPath = (control.addonFanart(), control.addonThumb(), control.artPath(),)
        for i in items:
            label = i.get("label")
            url = i.get("fullpath")
            thumb = i.get("icon")
            item = control.item(label=label)  # create ListItem
            item.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": addonFanart, })
            item.setInfo(type="Video", infoLabels={'year': i.get("year")})
            control.addItem(handle=handle, url=url, listitem=item, isFolder=True)
        control.directory(handle, cacheToDisc=True)
    else:
        control.directory(handle, cacheToDisc=False)  # obowiązkowo
        # control.log("akcja wstecz", 1)
        control.execute('Action(Back)')
        action = "nothing"


elif action == "similar" or action == "tvsimilar":
    # content = params.get("content")
    # mediatype = params.get("mediatype")
    if not params.get("tmdb"):
        tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
        tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
        tmdb = tmdb if tmdb else None
    if "tv" in action:
        from resources.lib.indexers import tvshows
        tvshows.tvshows().similar(tmdb)
    else:
        from resources.lib.indexers import movies
        movies.movies().similar(tmdb)


elif action == "recommendations" or action == "tvrecommendations":
    # content = params.get("content")
    # mediatype = params.get("mediatype")
    if not params.get("tmdb"):
        tmdb = control.infoLabel('ListItem.Property(tmdb_id)')  # starsze Kodi ( < 20)
        tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
        tmdb = tmdb if tmdb else None
    if "tv" in action:
        from resources.lib.indexers import tvshows
        tvshows.tvshows().recommendations(tmdb)
    else:
        from resources.lib.indexers import movies
        movies.movies().recommendations(tmdb)


elif action == "collection":
    if not params.get("tmdb"):
        tmdb = control.infoLabel('ListItem.Property(collection_id)')
        # tmdb = control.infoLabel('ListItem.Property(tmdb)') if not tmdb else tmdb
        # tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
        # tmdb = control.infoLabel('ListItem.Property(url)') if not tmdb else tmdb
        tmdb = tmdb if tmdb else None
        if generate_short_path:
            if tmdb:
                control.window.setProperty('FanFilm.var.collection_id', tmdb)  # do pamięci
            else:
                tmdb = control.window.getProperty('FanFilm.var.collection_id')  # z pamięci
        if not tmdb:
            control.log("BŁĄD: brak zmiennej collection_id", 1)
    from resources.lib.indexers import movies
    movies.movies().collection(tmdb)


elif action == "customMovieCriteria":
    from resources.lib.indexers import movies
    movies.movies().custom()


elif action == "movieGenres":
    from resources.lib.indexers import movies
    movies.movies().genres()


elif action == "movieLanguages":
    from resources.lib.indexers import movies
    movies.movies().languages()


elif action == "movieCertificates":
    from resources.lib.indexers import movies
    movies.movies().certifications()


elif action == "movieYears":
    from resources.lib.indexers import movies
    movies.movies().years()


elif action == "movieYearsTop":
    from resources.lib.indexers import movies
    movies.movies().years_top()


elif action == "moviesAwards":
    from resources.lib.indexers import movies
    movies.movies().awards()


elif action == "movieCompanies":
    from resources.lib.indexers import movies
    movies.movies().companies()


elif action == "findMediaWithPerson":
    # control.log(f'{referer.get("action")=}',1)
    # if referer.get("action") not in ["movies", "tvshows"]:
    if not url and generate_short_path:
        # if referer.get("action") in ["moviePerson", "tvPerson", "searchPerson"]:  # już raczej niepotrzebne
        url = control.infoLabel('ListItem.Property(urlD)')  # tylko, że przy powrocie może wziąść url od filmu a nie od osoby
        if url:
            control.window.setProperty('FanFilm.var.url.findMediaWithPerson', url)  # do pamięci
        else:
            url = control.window.getProperty('FanFilm.var.url.findMediaWithPerson')  # z pamięci
    if url:
        yatse = control.setting("yatse") == "true"
        # yatse = True  # testy
        if yatse:
            if not generate_short_path:
                from urllib.parse import quote_plus
                # control.addItem(handle, sys.argv[0]+f"?action=movies&url={quote_plus(url.replace('/ask_', '/movie_'))}", control.item("znajdź powiązane filmy"), True)
                control.addItem(handle, sys.argv[0]+f"?action=movies&url={quote_plus(url.replace('/ask_', '/movie_'))}&r=1", control.item("znajdź powiązane filmy"), True)
                # control.addItem(handle, sys.argv[0]+f"?action=tvshows&url={quote_plus(url.replace('/ask_', '/tv_'))}", control.item("znajdź powiązane seriale"), True)
                control.addItem(handle, sys.argv[0]+f"?action=tvshows&url={quote_plus(url.replace('/ask_', '/tv_'))}&r=1", control.item("znajdź powiązane seriale"), True)
            else:
                item = control.item("znajdź powiązane filmy")
                item.setProperty("url", url.replace("/ask_", "/movie_"))
                # control.addItem(handle, sys.argv[0]+"?action=movies", item, True)
                control.addItem(handle, sys.argv[0]+"?action=movies&r=1", item, True)

                item = control.item("znajdź powiązane seriale")
                item.setProperty("url", url.replace("/ask_", "/tv_"))
                # control.addItem(handle, sys.argv[0]+"?action=tvshows", item, True)
                control.addItem(handle, sys.argv[0]+"?action=tvshows&r=1", item, True)

            control.directory(handle, cacheToDisc=True, updateListing=False)
        else:
            selected = control.dialog.contextmenu(["powiązane filmy", "powiązane seriale", "wszystkie produkcje"])
            if selected > -1:
                # control.log(f'{sys.argv[2]=}',1)
                # sys_argv2 = sys.argv[2]
                if selected == 0:
                    action = "movies"
                    url = url.replace("/ask_", "/movie_")
                    # sys_argv2 = sys_argv2.replace("%2fask_", "%2fmovie_")
                elif  selected == 1:
                    action = "tvshows"
                    url = url.replace("/ask_", "/tv_")
                    # sys_argv2 = sys_argv2.replace("%2fask_", "%2ftv_")
                elif  selected == 2:
                    action = "multi"
                    url = url.replace("/ask_", "/combined_")
                    # sys_argv2 = sys_argv2.replace("%2fask_", "%2fcombined_")

                # sys_argv2 = sys_argv2.replace("action=findMediaWithPerson", f"action={action}")

                # control.log(f'url: {f"?action={action}&url={url}"}',1)

                control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę chwilkę poczekać ..."), False)  # opcjonalnie
                control.directory(handle, cacheToDisc=False, updateListing=False)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
                control.sleep0(100)

                if generate_short_path:
                    control.window.setProperty('FanFilm.var.url', url)  # do pamięci
                    control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
                    # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + ')' )
                    control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + '&r=1)' )
                else:
                    control.log("przekierowanie (odświeżenie)", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
                    # control.execute( 'Container.Update(' + sys.argv[0] + sys_argv2 + ')' )
                    # control.execute( 'Container.Update(' + sys.argv[0] + sys_argv2 + '&r=1)' )
                    # albo
                    from urllib.parse import quote_plus
                    # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&url={quote_plus(url)}" + ')' )
                    control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&url={quote_plus(url)}" + '&r=1)' )
            else:
                # control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" pusta zawartość "), False)  # do testów
                pass
    else:
        control.log("PROBLEM: brak zmiennej url", 1)


elif action == "searchActor":
    selected = control.dialog.contextmenu(["Aktorzy filmowi", "Aktorzy serialowi"])
    if selected > -1:
        if selected == 0:
            action = "moviePerson"
        elif  selected == 1:
            action = "tvPerson"
        control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}" + ')' )
        # control.execute( 'Container.Update(' + sys.argv[0] + f"?action={action}&media_type=ask" + ')' )
        # control.sleep0(100)
        # action = "nothing"


elif action == "searchPerson":
    page = params.get("page")
    if page and not url:
        url = control.infoLabel('ListItem.Property(urlDNext)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url.searchPerson', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url.searchPerson')  # z pamięci
        import re
        url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
    if page and "page" not in url:
        q_or_a = "&" if "?" in url else "?"
        url += f"{q_or_a}page={page}"
    # control.log(f'{action=} {url=}', 1)
    if total_pages := params.get("total_pages"):
        action = obsluga_wyboru_strony(url, total_pages)
        # control.log(f'{action=}', 1)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            department = params.get("department", "all")
            media_type = params.get("media_type", "ask")
            # category = params.get("category", "")
            category = dict(parse_qsl(url)).get("query") or ""
            from resources.lib.indexers import movies  # tam umieściłem, aby nie tworzyć nowego pliku
            movies.movies().person(url, department=department, media_type=media_type, category=category)
        else:
            pass
            przekierowanie("?action=personSearch")


elif action == "moviePerson":
    page = params.get("page")
    if page and not url:
        url = control.infoLabel('ListItem.Property(urlDNext)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url.moviePerson', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url.moviePerson')  # z pamięci
        import re
        url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
    if page and "page" not in url:
        q_or_a = "&" if "?" in url else "?"
        url += f"{q_or_a}page={page}"
    # control.log(f"{url=}", 1)
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            # department = params.get("department", "Acting")
            # media_type = params.get("media_type", "movie")
            from resources.lib.indexers import movies
            movies.movies().person(url)
            # movies.movies().person(url, department=department, media_type=media_type)
        else:
            przekierowanie("?action=moviePerson")


elif action == "moviePersons":  # chyba niewywoływane stąd
    if not url:
        control.log("BŁĄD: brak zmiennej url", 1)
    """
    if not url:
        url = control.infoLabel('ListItem.Property(url)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url')  # z pamięci
        page = params.get("page")
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
    # control.log(f'{action=} {url=}', 1)
    """
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            from resources.lib.indexers import movies
            movies.movies().persons(url)
        else:
            przekierowanie("?action=moviePersons")


elif action == "movieUserlists":
    from resources.lib.indexers import movies
    refresh = params.get("refresh")
    # refresh = 1  # zawsze
    movies.movies().userlists(refresh=refresh)


elif action == "channels" or action == "movieSearchFromEPG":
    from resources.lib.indexers import channels
    channels.channels().get()


elif action == "tvshows" or action == "tvshowPage":
    if not url:
        url = control.infoLabel('ListItem.Property(url)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url')  # z pamięci
        page = params.get("page")
        # control.log(f'{page=}',1)
        if generate_short_path:
            if referer and referer.get("page") or not referer and prev_lastpath and prev_lastpath.get("page"):
                page = page or 1  # to nie zawsze jest dobrze, bo np. dla list trakt
        if page and "page" not in url:
            q_or_a = "&" if "?" in url else "?"
            url += f"{q_or_a}page={page}"
    # control.log(f'{action=} {url=}', 1)
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            refresh = params.get("refresh")
            category = dict(parse_qsl(url)).get("query") or ""
            # control.log(f'{action=} {category=}', 1)
            if not category:
                item = params.get("item") or ""
                # from urllib.parse import unquote
                # item = unquote(item)
                try:
                    category = item  if not item.isnumeric() or 1900 <= int(item) <= 2999  else ""
                except:
                    pass
                # control.log(f'{action=} {category=}', 1)
            from resources.lib.indexers import tvshows
            tvshows.tvshows().get(url, refresh=refresh, category=category)
        else:
            przekierowanie("?action=tvNavigator")
            # przekierowanie("?action=tvNavigator")  # nie wiem, które lepiej


elif action == "tvSearch":
    control.window.clearProperty('FanFilm.var.name')  # wyczyszcenie
    from resources.lib.indexers import tvshows
    tvshows.tvshows().search()


elif action == "tvSearchnew":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().search_new()


elif action == "tvSearchterm":
    if not params.get("name"):
        folderpath = control.infoLabel('Container.FolderPath') 
        referer = dict(parse_qsl(folderpath.split('?')[-1]))
        if referer.get("action") == "tvSearch":
            name = control.infoLabel('ListItem().Label')  # z wybranej pozycji
            control.window.setProperty('FanFilm.var.name', name)  # do pamięci
            # control.log(f'do pamieci', 1)
        else:
            name = control.window.getProperty('FanFilm.var.name')  # z pamięci
            # control.log(f'z pamieci', 1)
    from resources.lib.indexers import tvshows
    tvshows.tvshows().search_term(name)


elif action == "tvPerson":
    page = params.get("page")
    if page and not url:
        url = control.infoLabel('ListItem.Property(urlDNext)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url.tvPerson', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url.tvPerson')  # z pamięci
        import re
        url = re.sub("((?<=[?/])|&)page[=/][^&]", "", url).replace("?&", "?").rstrip("?&")
    if page and "page" not in url:
        q_or_a = "&" if "?" in url else "?"
        url += f"{q_or_a}page={page}"
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            from resources.lib.indexers import tvshows
            tvshows.tvshows().person(url)
        else:
            przekierowanie("?action=tvPerson")


elif action == "tvPersons":  # już chyba niewywoływane stąd
    if not url:
        control.log("BŁĄD: brak zmiennej url", 1)
    if total_pages := params.get("total_pages") :
        action = obsluga_wyboru_strony(url, total_pages)
    if action and action != "nothing":
        if not action.startswith("BackToMain|"):
            from resources.lib.indexers import tvshows
            tvshows.tvshows().persons(url)
        else:
            przekierowanie("?action=tvPersons")


elif action == "customTvCriteria":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().custom()


elif action == "tvGenres":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().genres()


elif action == "tvNetworks":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().networks()


elif action == "tvLanguages":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().languages()


elif action == "tvCertificates":
    certification_country = params.get("certification_country")
    from resources.lib.indexers import tvshows
    tvshows.tvshows().certifications(certification_country)


elif action == "tvYears":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().years()


elif action == "tvYearsTop":
    from resources.lib.indexers import tvshows
    tvshows.tvshows().years_top()


elif action == "tvUserlists":
    from resources.lib.indexers import tvshows
    refresh = params.get("refresh")
    # refresh = 1  # zawsze
    tvshows.tvshows().userlists(refresh=refresh)


elif action == "seasons":
    meta = params.get("meta")
    localtvshowtitle = params.get("localtvshowtitle")

    if not params.get("tvshowtitle"):
        tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
        tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
        tvshowtitle = control.infoLabel('ListItem.Property(englishTitle)') if not tvshowtitle else tvshowtitle
        tvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not tvshowtitle else tvshowtitle
    if not params.get("localtvshowtitle"):
        localtvshowtitle = control.infoLabel('ListItem.TvShowTitle') 
        localtvshowtitle = control.infoLabel('ListItem.Title') if not localtvshowtitle else localtvshowtitle
    if not params.get("originaltvshowtitle"):
        originaltvshowtitle = control.infoLabel('ListItem.Property(OriginalTvShowTitle)')
        originaltvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not originaltvshowtitle else originaltvshowtitle
        # control.log(f'{originaltvshowtitle=}', 1)
    if not params.get("year"):
        year = control.infoLabel('ListItem.Property(TvShowYear)')
        year = control.infoLabel('ListItem.Year') if not year else year
    if not params.get("imdb"):
        imdb = control.infoLabel('ListItem.Property(imdb_id)')
        imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb
    if not params.get("tmdb"):
        tmdb = control.infoLabel('ListItem.Property(tmdb_id)')
        tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb
    if not params.get("tvdb"):
        tvdb = control.infoLabel('ListItem.Property(tvdb_id)')
        tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb
    if not params.get("meta"):
        meta = control.infoLabel('ListItem.Property(meta)')

    #if not tvshowtitle or not tmdb:  # czemu tylko tmdb a nie imdb ?
    if not tvshowtitle or not tmdb and not imdb:  # próba
        control.log(f'z pamieci', 0)
        zmienne = control.window.getProperty('FanFilm.var.curr_item_s')  # z pamięci
        if zmienne:
            zmienne = eval(zmienne)
            globals().update(zmienne)  # opcjonalnie
    else:
        control.log(f'do pamieci', 0)
        #zmienne = (tvshowtitle, year, imdb, tmdb, meta)
        zmienne = {"tvshowtitle":tvshowtitle, "year":year, "imdb":imdb, "tmdb":tmdb, "tvdb":tvdb, "meta":meta, "localtvshowtitle":localtvshowtitle, "originaltvshowtitle":originaltvshowtitle}
        control.window.setProperty('FanFilm.var.curr_item_s', repr(zmienne))  # do pamięci
    
    control.log(f" [ KONTROLA_s ] {tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {localtvshowtitle=} {originaltvshowtitle=}  {meta=}", 0)

    select = control.setting("hosts.mode")
    if control.setting("generate_short_path") == "true" and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
        control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
        control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
        control.directory(handle, cacheToDisc=False, updateListing=True)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
        control.sleep0(100)
        control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 0)  # tu dodatkowe polecenie jako zwłoka przed następnym
        control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')
        action = "nothing"
    else:
        from resources.lib.indexers import episodes
        episodes.seasons().get(tvshowtitle, year, imdb, tmdb, tvdb, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle)


elif action == "episodes":
    zmienne = None
    #if not tvshowtitle or not tmdb:  # czemu tmdb a nie imdb ?
    # if not tvshowtitle or not (tmdb and imdb):  # próba, czy będzie dobrze działać
    # NumItems = control.infoLabel("Container().NumItems")  # często pokazuje informacje przed odświeżeniem, także nieprzydatne wówczas (a jak pokazuje, to czasami jest puste a czasami 0 - i bądź tu mądry)
    # NumItems = int(NumItems) if NumItems else 0
    control.log(f'{referer=}', 0)
    # if generate_short_path and (not referer or not NumItems) or params.get("r"):  # ryzykowniejsze, bo trafiła mi się nieskończona pętla
    if generate_short_path and (not referer or referer.get("action") not in ["seasons", "calendar", "tvSearchterm"]) or params.get("r"):
        control.log(f'z pamieci (próba)', 0)
        zmienne = control.window.getProperty('FanFilm.var.curr_item_e')  # z pamięci
        if zmienne:
            zmienne = eval(zmienne)
            globals().update(zmienne)
        else:
            control.log(f'nieudana próba', 0)
            pass

    # globals().update(params)  # priorytet mają te podane w adresie  # to chyba niebezpieczne

    # if not tvshowtitle or not tmdb and not imdb:
    if not zmienne:
        # pobranie wszystkich potrzebnych zmiennych
        # jak podane w url, to priorytet nad kryjącym się w ListItem
        # season = params.get("season")  # to jest na początku tego pliku
        # episode = params.get("episode")  # j.w.
        meta = params.get("meta")
        localtvshowtitle = params.get("localtvshowtitle") or ""
        originaltvshowtitle = params.get("originaltvshowtitle") or ""

        # control.log(f'{generate_short_path=}  {referer=}', 1)
        if generate_short_path and referer:
            control.log(f'odczytywanie z ListItemu', 0)
            if not episode:
                episode = control.infoLabel('ListItem.Episode')  # nie można tego przy odświeżaniu
                episode = episode if episode else None  # ważne jest None (choć 0 i '' też daje not episode)

            if not season:
                season = control.infoLabel('ListItem.Season')
                season = season if season else None  # ważne tu

            if not meta:
                meta = control.infoLabel('ListItem.Property(meta)')

            if not year:
                year = control.infoLabel('ListItem.Property(TvShowYear)')
                year = control.infoLabel('ListItem.Year') if not year else year

            if not imdb:
                imdb = control.infoLabel('ListItem.Property(imdb_id)')
                imdb = control.infoLabel('ListItem.UniqueID(imdb)') if not imdb else imdb

            if not tmdb:
                tmdb = control.infoLabel('ListItem.Property(tmdb_id)')
                tmdb = control.infoLabel('ListItem.UniqueID(tmdb)') if not tmdb else tmdb

            if not tvdb:
                tvdb = control.infoLabel('ListItem.Property(tvdb_id)')
                tvdb = control.infoLabel('ListItem.UniqueID(tvdb)') if not tvdb else tvdb

            if not tvshowtitle:
                tvshowtitle = control.infoLabel('ListItem.Property(englishTvShowTitle)')
                tvshowtitle = control.infoLabel('ListItem.TvShowTitle') if not tvshowtitle else tvshowtitle
                tvshowtitle = control.infoLabel('ListItem.Property(englishTitle)') if not tvshowtitle else tvshowtitle
                tvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not tvshowtitle else tvshowtitle

            if not localtvshowtitle:
                localtvshowtitle = control.infoLabel('ListItem.TvShowTitle')
                localtvshowtitle = control.infoLabel('ListItem.Title') if not localtvshowtitle else localtvshowtitle
                # control.log(f'{originaltvshowtitle=}', 1)

            if not originaltvshowtitle:
                originaltvshowtitle = control.infoLabel('ListItem.Property(OriginalTvShowTitle)')
                originaltvshowtitle = control.infoLabel('ListItem.OriginalTitle') if not originaltvshowtitle else originaltvshowtitle
                # control.log(f'{originaltvshowtitle=}', 1)

        #zmienne = (tvshowtitle, year, imdb, tmdb, meta)
        zmienne = {"tvshowtitle":tvshowtitle, "year":year, "imdb":imdb, "tmdb":tmdb, "tvdb":tvdb, "meta":meta,
                   "season":season, "episode":episode, "localtvshowtitle":localtvshowtitle, "originaltvshowtitle":originaltvshowtitle}

        if generate_short_path:
            if not tvshowtitle or not tmdb and not imdb:  # to się bardzo przydaje
                control.log(f'zmienne nie zostaną zapamiętane, bo {tvshowtitle=} {tmdb=} {imdb=}', not(logsilent))
                pass
            else:
                control.log(f'do pamieci', 0)
                control.window.setProperty('FanFilm.var.curr_item_e', repr(zmienne))  # do pamięci

    control.log(f" [ KONTROLA_e ] {tvshowtitle=} {year=} {imdb=} {tmdb=} {tvdb=} {season=} {episode=} {localtvshowtitle=} {originaltvshowtitle=}  {meta=}", 0)

    select = control.setting("hosts.mode")
    # control.log(f'{select=}', 1)

    # sprawdzenie, czy zrobić jeszcze dodatkowe przekerowanie
    # a może zrobić z tego funkcję? bo się powtarza w kilku miejscach
    # control.log(f" {sys.argv=} ", 1)
    import time
    if generate_short_path and (params.get("title") or params.get("tvshowtitle")) and select == "1" and not params.get("r"):
        if (not (r_time := control.window.getProperty('FanFilm.var.r_time')) or int(r_time) < int(time.time()) - 2):  # ma służyć przed nieskończonym przekierowaniem w niektórych sytuacjach (jak np. błąd pythona w trakcie wykonywania kodu)
            control.window.setProperty('FanFilm.var.r_time', str(int(time.time())) )  # ustawienie znacznika r
            control.log(f'będzie przekierowanie jeszcze', not(logsilent))
            control.window.setProperty('FanFilm.var.before_r', repr(params))  # do pamięci
            control.addItem(handle, sys.argv[0]+"?action=nothing", control.item(" proszę czekać ..."), False)  # opcjonalnie
            control.directory(handle, cacheToDisc=False, updateListing=True)  # obowiązkowo i musi być False, bo przy True nie chce robić przekierowania, gdy wyświetla stronę z cachu
            control.sleep0(100)
            # control.log("przekierowanie (odświeżenie) z obcięciem parametrów", 1)  # tu dodatkowe polecenie jako zwłoka przed następnym
            control.execute('Container.Update(' + sys.argv[0]+f"?action={action}&r=1" + ')')  # uruchomienie przekierowania
            action = "nothing"
        else:
            control.log(f"przekierowanie zostało zablokowane", not(logsilent))
            action = "nothing"  # nie wiem, czy dać
            pass
    else:  # można wreszcie wywołać właściwą funkcję
        from resources.lib.indexers import episodes
        episodes.episodes().get(tvshowtitle, year, imdb, tmdb, tvdb, season, episode, meta, localtvshowtitle=localtvshowtitle, originaltvshowtitle=originaltvshowtitle)
        control.window.clearProperty('FanFilm.var.r_time')  # reset (może dać na sam koniec)


elif action == "calendar":
    # control.log(f'{url=}', 1)
    if not url:
        url = control.infoLabel('ListItem.Property(url)')
        if url:
            # control.log(f'do pamieci', 1)
            control.window.setProperty('FanFilm.var.url', url)  # do pamięci
        else:
            # control.log(f'z pamieci', 1)
            url = control.window.getProperty('FanFilm.var.url')  # z pamięci
    # control.log(f'{url=}', 1)
    refresh = params.get("refresh")
    from resources.lib.indexers import episodes
    episodes.episodes().calendar(url, refresh)


elif action == "tvWidget":
    from resources.lib.indexers import episodes
    episodes.episodes().widget()


elif action == "calendars":
    from resources.lib.indexers import episodes
    episodes.episodes().calendars()


elif action == "episodeUserlists":
    from resources.lib.indexers import episodes
    episodes.episodes().userlists()


elif action == "refresh":
    from ptw.libraries import control
    control.refresh()


elif action == "queueItem":
    from ptw.libraries import control
    control.queueItem()


elif action == "openSettings":
    from ptw.libraries import control
    control.openSettings(params.get("query"))


elif action == "artwork":
    from ptw.libraries import control
    control.artwork()


elif action == "addView":
    from ptw.libraries import views
    views.addView(params.get("content"))


elif action == "moviePlaycount":
    from ptw.libraries import playcount
    playcount.movies(imdb, params.get("query"))


elif action == "episodePlaycount":
    from ptw.libraries import playcount
    playcount.episodes(imdb, tvdb, season, episode, params.get("query"))


elif action == "tvPlaycount":
    control.busy()
    control.sleep(400)
    from ptw.libraries import playcount
    playcount.tvshows(name, imdb, tmdb, season, params.get("query"))
    control.idle(2)


elif action == "trailer":
    # Zamknij = False  # gdzie to ma przełożenie ?
    windowedtrailer = params.get("windowedtrailer")
    # windowedtrailer = "1"  # nie wiem, co to ma dawać, bo i tak odtwarza się na całym ekranie
    windowedtrailer = int(windowedtrailer) if windowedtrailer in ("0", "1") else 0
    # control.log(f'{name=} {url=} {windowedtrailer=}', 1)
    from ptw.libraries import trailer
    trailer.trailer().play(name, url, windowedtrailer)


elif action == "tmdbManager":
    overlay = params.get("overlay")
    percent = int(params.get("percent") or 0)
    progress = int(params.get("progress") or 0)
    WatchedEpisodes = int(params.get("WatchedEpisodes") or 0) # dla seriali (ilość odcinków)
    content = params.get("content")
    if content == "movie":
        from resources.lib.indexers import movies
        movies.movies().tmdbManager(content, tmdb, overlay=overlay, progress=progress)
    if content in ["tvshow", "show", "tv"]:
        content = "tv"  # powinno być tv, bo tak ma tmdb to zdefiniowane
        from resources.lib.indexers import tvshows
        tvshows.tvshows().tmdbManager(content, tmdb, overlay=overlay, WatchedEpisodes=WatchedEpisodes)
        pass
    if content == "episode":
        # chyba tylko ocenianie
        # from resources.lib.indexers import episodes
        # episodes.episodes().tmdbManager(content, tmdb, season, episode)
        pass


elif action == "traktManager":
    from ptw.libraries import trakt
    content = params.get("content")
    overlay = params.get("overlay")
    trakt.manager(name, imdb, tmdb, content, season, episode, overlay)


elif action == "authTrakt":
    from ptw.libraries import trakt
    result = trakt.authTrakt()
    if result:  # True
        # control.dialog.notification("FanFilm", "Trakt - operacja powiodła się\nZalecane jest ponowne uruchomienie Kodi")  # chyba niepotrzebne, jak sys.exit() załatwi sprawę
        control.dialog.notification("FanFilm", "Trakt - operacja powiodła się")
        from ptw.libraries import cache
        cache.cache_remove("", "%.trakt_%")
        sys.exit()  # pozwala chyba przerwać sesję, aby pozbyć się zapamiętanych ustawień i niektórych zmiennych z cache
    elif result is None:
        control.dialog.notification("FanFilm", "Trakt\nCoś poszło nie tak - sprawdź log")
    else:  # False
        control.dialog.notification("FanFilm", "Trakt\nPrzerwano proces")


elif action == "pairEkino":
    from resources.lib.sources.pl import ekinotv
    ekinotv.source().pair_scraper()


elif action == "smuSettings":
    try:
        import resolveurl
    except Exception:
        pass
    resolveurl.display_settings()


elif action == "reset_download_paths":
    if 0:
        import os
        dataPath = control.dataPath
        movie_download_path = os.path.join(dataPath, "Movies")  # nie wiem, skąd nazwy tych folderów (czyżby Kodi miał je gdzieś ustawione?)
        tv_download_path = os.path.join(dataPath, "TVShows")  # j.w.
    else:
        dataPath = f"special://profile/addon_data/{control.addonId()}/"
        # dataPath = control.transPath(dataPath)  # niepotrzebne
        movie_download_path = dataPath + "Movies"  # nie wiem, skąd nazwy tych folderów (czyżby Kodi miał je gdzieś ustawione?)
        tv_download_path = dataPath + "TVShows"  # j.w.
    if not control.existsPath(movie_download_path):
        control.makeDirs(movie_download_path)
        if not dataPath.startswith("special://"):
            movie_download_path += os.sep
    if not control.existsPath(tv_download_path):
        control.makeDirs(tv_download_path)
        if not dataPath.startswith("special://"):
            tv_download_path += os.sep
    control.setSetting('movie.download.path', movie_download_path)
    control.setSetting('tv.download.path', tv_download_path)


elif action == "download":
    # control.log(f'{action=}', 1)
    """
    downloads = (True  if (
                            control.setting("downloads") == "true"
                            and (len(control.listDir(control.setting("movie.download.path"))[0]) > 0 
                              or len(control.listDir(control.setting("movie.download.path"))[1]) > 0
                              or len(control.listDir(control.setting("tv.download.path"))[0]) > 0  # seriale zawsze są (albo powinny być) w folderach
                              or len(control.listDir(control.setting("tv.download.path"))[1]) > 0  # test
                                )
                          )
                 else False)
    """
    downloads = (
        control.setting("downloads") == "true"
        and not (
            control.setting("movie.download.path") == ""
            or control.setting("tv.download.path") == ""
        )
    )
    if not downloads:
        control.log(f'[FanFilm] {action=}  Pobieranie niemożliwe! - sprawdź ustawienia i parametry (foldery) pobierania',1)
        control.log(f'[FanFilm] {control.setting("movie.download.path")=}',1)
        control.log(f'[FanFilm] {control.setting("tv.download.path")=}',1)
        control.infoDialog('Pobieranie niemożliwe!\nsprawdź ustawienia i parametry (foldery) pobierania', sound=True, icon="ERROR")
        action = "nothing"
    else:
        control.busy()
        control.sleep(200)
        image = params.get("image")
        extrainfo = params.get("extrainfo", "")
        season_name = params.get("season_name", "")
        Zamknij = False  # gdzie to ma przełożenie ?
        url = params.get("url")
        if not url:
            source = params.get("source")
            from ptw.libraries import sources
            import json
            url = sources.sources().sourcesResolve(json.loads(source)[0], True)  # jak wywołanie jest z folderu (nie z okna)
        from ptw.libraries import downloader
        downloader.download(name, image, url, extrainfo, season_name)
        control.idle(2)

    
elif action == "buyItemAgain":
    from ptw.libraries import sources
    sources.sources().playItem(title, params.get("source"), for_sourcesResolve={'for_resolve': {'buy_anyway': True}})


elif action == "alterSources":
    #if not url:
        #control.log("BŁĄD: brak zmiennej url", 1)
    from ptw.libraries import sources
    sources.sources().alterSources(url, params.get("meta"))


elif action == "clearSources":
    from ptw.libraries import sources
    sources.sources().clearSources()


elif action == "random":
    if not url:
        control.log("BŁĄD: brak zmiennej url", not(logsilent))
    rtype = params.get("rtype")
    if rtype == "movie":
        from resources.lib.indexers import movies
        rlist = movies.movies().get(url, create_directory=False)
        r = sys.argv[0] + "?action=play"
    elif rtype == "episode":
        from resources.lib.indexers import episodes
        rlist = episodes.episodes().get(tvshowtitle, year, imdb, tmdb, season, create_directory=False)
        r = sys.argv[0] + "?action=play"
    elif rtype == "season":
        from resources.lib.indexers import episodes
        rlist = episodes.seasons().get(tvshowtitle, year, imdb, tmdb, create_directory=False)
        r = sys.argv[0] + "?action=random&rtype=episode"
    elif rtype == "show":
        from resources.lib.indexers import tvshows
        rlist = tvshows.tvshows().get(url, create_directory=False)
        r = sys.argv[0] + "?action=random&rtype=season"

    #from ptw.libraries import control
    from urllib.parse import quote_plus
    from random import randint
    import json

    select = params.get("select")  # nie wiem czy to tu potrzebne
    meta = params.get("meta")  # to samo co wyżej
    premiered = params.get("premiered")  # to samo co wyżej
    try:
        rand = randint(1, len(rlist)) - 1
        for p in ["title", "year", "imdb", "tmdb", "season", "episode", "tvshowtitle", "premiered", "select", ]:
            if rtype == "show" and p == "tvshowtitle":
                try:
                    r += "&" + p + "=" + quote_plus(rlist[rand]["title"])
                except Exception:
                    pass
            else:
                try:
                    r += "&" + p + "=" + quote_plus(rlist[rand][p])
                except Exception:
                    pass
        try:
            r += "&meta=" + quote_plus(json.dumps(rlist[rand]))
        except Exception:
            r += "&meta=" + quote_plus("{}")
        if rtype == "movie":
            try:
                control.infoDialog(rlist[rand]["title"], control.lang(32536), time=30000, )
            except Exception:
                pass
        elif rtype == "episode":
            try:
                control.infoDialog(
                    rlist[rand]["tvshowtitle"] + " - Season " + rlist[rand]["season"] + " - " + rlist[rand][
                        "title"], control.lang(32536), time=30000, )
            except Exception:
                pass
        control.execute("RunPlugin(%s)" % r)
    except Exception:
        control.infoDialog(control.lang(32537), time=8000)


elif action == "movieToLibrary":
    from ptw.libraries import libtools
    libtools.libmovies().add(name, title, localtitle, year, imdb, tmdb)


elif action == "moviesToLibrary":
    #if not url:
        #control.log("BŁĄD: brak zmiennej url", 1)
    PluginName = control.infoLabel('Container.PluginName')  # jak pusty, lub nie 'plugin.video.fanfilm', to oznacza, że wywoływane z innego pluginu
    isFolder = control.condVisibility('ListItem.IsFolder')  # nie zawsze sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
    control.log(f"[FanFilm] {isFolder=} {PluginName=}", not(logsilent))
    if isFolder:
        control.directory(handle)
        control.execute('Action(Back)')
    from ptw.libraries import libtools
    libtools.libmovies().range(url)


elif action == "moviesMultiToLibrary":
    from ptw.libraries import libtools
    libtools.libmovies().multi(params.get("select"))


elif action == "moviesToLibrarySilent":
    #if not url:
        #control.log("BŁĄD: brak zmiennej url", 1)
    from ptw.libraries import libtools
    libtools.libmovies().silent(url)


elif action == "tvshowToLibrary":
    from ptw.libraries import libtools
    meta = params.get("meta")
    localtvshowtitle = params.get("localtvshowtitle")
    libtools.libtvshows().add(tvshowtitle, year, imdb, tmdb, season, episode, meta, localtvshowtitle=localtvshowtitle)


elif action == "tvshowsToLibrary":
    #if not url:
        #control.log("BŁĄD: brak zmiennej url", 1)
    PluginName = control.infoLabel('Container.PluginName')  # jak pusty, lub nie 'plugin.video.fanfilm', to oznacza, że wywoływane z innego pluginu
    isFolder = control.condVisibility('ListItem.IsFolder')  # nie zawsze sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
    control.log(f"[FanFilm] {isFolder=} {PluginName=}", not(logsilent))
    if isFolder:
        control.directory(handle)
        control.execute('Action(Back)')
    from ptw.libraries import libtools
    libtools.libtvshows().range(url)


elif action == "tvshowsToLibrarySilent":
    #if not url:
        #control.log("BŁĄD: brak zmiennej url", 1)
    from ptw.libraries import libtools
    libtools.libtvshows().silent(url)


elif action == "updateLibrary":
    from ptw.libraries import libtools
    libtools.libepisodes().update(params.get("query"))


elif action == "moviesAndtvshowsToLibrarySilent":
    movies = int(params.get("movies") or 0)
    tvshows = int(params.get("tvshows") or 0)
    from ptw.libraries import libtools
    if movies:
        libtools.libmovies().silent(url)  
    if tvshows:
        libtools.libtvshows().silent(url)


elif action == "tmdbauthorize":
    from ptw.libraries import tmdbauth
    # tmdbauth.Auth().create_session_id()  # v3
    tmdbauth.Auth().generate_access_token()  # v4


elif action == "tmdbdeauthorize":
    from ptw.libraries import tmdbauth
    tmdbauth.Auth().revoke_session_id()


elif action == "libepisodesservice":
    # przeniosłem uruchamianie do service.py
    if True:
        control.log("[FanFilm]  starting cyclic checking and updating library episodes process", not(logsilent))
        from ptw.libraries import libtools
        libtools.libepisodes().service()


elif action == "lastWatched":
    from ptw.libraries import bookmarks
    limit = int(control.setting("lastWatchedList.limit"))
    positions = bookmarks.last_positions(999)  # trzeba pobierać więcej (nie wiem ile sensownie), bo odcinki będą zmniejszały ostateczną ilość pokazywanych tytułów
    from resources.lib.indexers import movies
    # media_type, imdb, season, episode  = position
    # lista = [{"imdb": imdb, "media_type": media_type}, ]
    # lista.append({"imdb": "tt18335752", "media_type": "episode"})  # do testów tylko
    # control.log(f'{positions=}',1)
    lista = [{"imdb":p[1], "media_type":p[0]} for p in positions if p[1] and p[1]!="0" and p[1]!="None"]
    lista = [i for n, i in enumerate(lista) if i not in lista[:n]]  # eliminacja dubli
    lista = lista[:limit]
    movies.movies().list_by_imdb_or_tmdb(lista, "Ostatnio oglądane")


elif action == "removeFromBookmarks":
    content = params.get("content")
    term = control.infoLabel('ListItem.Label') or ""
    yes = control.yesnoDialog(f'Czy chcesz usunąć z lokalnej historii FanFilm[CR][B]{term}[/B] ?'+
                               '\n[LIGHT]Spowoduje to także utratę lokalnego statusu [I]Obejrzany w FanFilm[/I][/LIGHT]'+
                               ('\ndla wszystkich odcinków' if content=="tvshow" else '')
                             )
    if yes:
        from ptw.libraries import bookmarks
        bookmarks._delete_record(content, imdb, season, episode)
        control.refresh()


elif action == "deleteFile":
    dest = params.get("file")
    control.log(f'[FanFilm] {action=}  plik {dest=}',1)
    if (
        control.yesnoDialog(
            "Czy chcesz [B]skasować[/B] następujący plik?" + f"\n\n[LIGHT][I]{dest}[/I][/LIGHT]",
            yeslabel="Skasuj",
            nolabel="Zostaw",
            heading="Wymagane potwierdzenie",
        )
    ):
        # control.log(f'[FanFilm] {action=}  plik zostanie skasowany',1)
        try:
            successed = control.deleteFile(dest)
            if not successed:
                control.log(f'[FanFilm] {action=}  nie udało się skasować pliku',1)
                control.infoDialog('Wystąpił jakiś błąd', sound=True, icon="ERROR")
            else:
                # control.log(f'[FanFilm] {action=}  wymuszenie odświeżenia listy źródeł', 1)
                # control.window.clearProperty('imdb_id')  # będzie szukał ponownie wszystkich
                # control.window.clearProperty(self.itemRejected)  # nie wiem, czy to też potrzeba

                # from getConstants in sources.py
                class self: pass
                self.itemProperty = "plugin.video.fanfilm.container.items"
                self.itemRejected = "plugin.video.fanfilm.container.itemsRejected"
                items = control.window.getProperty(self.itemProperty)
                import json
                try:
                    items = json.loads(items)
                except:
                    items = []
                # control.log(f'[FanFilm] {action=}  \n{len(items)=}  {items=}',1)
                # items = [i for i in items if i.get("url")!=dest]  # przeszukuje do końca
                flags = False
                for i in items:
                    if i.get("url") == dest:
                        items.remove(i)
                        flags = True
                        break
                if flags:
                    # brakuje ewentualnego przenumerowania jeszcze
                    control.window.setProperty(self.itemProperty, json.dumps(items))
                else:
                    # control.window.clearProperty(self.itemRejected)
                    items = control.window.getProperty(self.itemRejected)
                    try:
                        items = json.loads(items)
                    except:
                        items = []
                    # control.log(f'[FanFilm] {action=}  \nitemsRejected  {len(items)=}  {items=}',1)
                    for i in items:
                        if i.get("url") == dest:
                            items.remove(i)
                            flags = True
                            break
                    if flags:
                        # brakuje ewentualnego przenumerowania jeszcze
                        control.window.setProperty(self.itemRejected, json.dumps(items))

                control.refresh()
        except Exception:
            control.log(f'[FanFilm] {action=}  wystąpił błąd podczas kasowania pliku',1)
            pass
        control.sleep(100)



elif action == "add_rating":  # or "delete_rating":
    control.log(f'start {action=}',1)

    control.busy()
    control.infoDialog('Proszę zaczekać', 'Ocena dla TMDB', sound=False)
    control.sleep(1000)

    import requests

    content = params.get("content")  # "movie" or "tv" (or "episode")

    from ptw.libraries import apis
    tm_user = control.setting("tm.user") or apis.tmdb_API

    if content == "episode":
        tmdb_rating_link = f"https://api.themoviedb.org/3/tv/%%s/season/{season}/episode/{episode}/rating?api_key=%s" % tm_user
    else:
        tmdb_rating_link = f"https://api.themoviedb.org/3/{content}/%%s/rating?api_key=%s" % tm_user

    tmdb_sessionid = control.setting("tmdb.sessionid") or ""

    control.busy()
    if tmdb_sessionid:
        # control.log(f'będzie sesja autoryzowanego użytkownika',1)
        tmdb_rating_link += "&session_id=%s" % tmdb_sessionid
        pass
    else:
        # control.busy()
        control.log(f'sesja dla gościa',1)
        control.infoDialog('trwa sprawdzanie sesji gościa', 'Ocena dla TMDB', sound=False)
        # sprawdzenie, czy jakiejś już nie ma
        # guest_session_id = None
        guest_session_id = control.setting('tmdb.guest_session_id')
        """
        guest_session = control.setting('tmdb.guest_session')
        control.log(f'odczytana z ustawień {guest_session=}',1)
        if guest_session:
            try:
                guest_session = eval(guest_session)
                guest_session_id = guest_session.get("guest_session_id")
            except:
                guest_session_id = guest_session
        else:
            guest_session_id = control.setting('tmdb.guest_session_id')
        guest_session = None  # niepotrzebna zmienna już
        """
        if guest_session_id:
            response = None
            # test, czy jeszcze ważny
            url = f'https://api.themoviedb.org/3/guest_session/{guest_session_id}/rated/movies?api_key={tm_user}'
            response = True
            response = requests.get(url)
            # response = None
            if response is not None and (response or response.status_code == 404):
                # klucz sesji ważny
                control.log(f'klucz sesji gościa jest niby ważny',1)
                # control.log(f'klucz sesji gościa jest niby ważny   {response=}  {url=}',1)
                control.log('potrzeba odczekania przed następnym requestem',1)
                control.sleep(9000)  # zwłoka większa
            else:
                control.log('klucz sesji gościa chyba już nie ważny',1)
                guest_session_id = ""
                # control.setSetting('tmdb.guest_session', '')
                control.setSetting('tmdb.guest_session_id', '')
                control.sleep(1000)  # zwłoka
        if not guest_session_id:
            # potrzebny nowy klucz sesji
            control.log('potrzebny nowy klucz sesji gościa',1)
            # control.infoDialog('generowanie nowej sesji gościa', 'Ocena dla TMDB', sound=False)
            response = requests.get(f'https://api.themoviedb.org/3/authentication/guest_session/new?api_key={tm_user}')
            if response:
                response = response.json()
                control.log(f'{response=}',1)
                if response.get("success") is True:
                    guest_session_id = response.get("guest_session_id")
                    # zachować sesję na godzinę "expires_at": response.get("expires_at")  # https://developer.themoviedb.org/reference/authentication-create-guest-session
                    # control.setSetting('tmdb.guest_session', repr(response))
                    # control.setSetting('tmdb.guest_session', guest_session_id)
                    control.setSetting('tmdb.guest_session_id', guest_session_id)
                else:
                    control.log(f'wystąpił jakiś problem  {response=}  {url=}',0)
                    control.log(f'wystąpił jakiś problem  {response=}',1)
            else:
                control.log(f'wystąpił jakiś problem  {response=}  {response.text=}  {url=}  ',0)
                control.log(f'wystąpił jakiś problem  {response=}  {response.text=}',1)
            control.log('potrzeba odczekania przed następnym requestem',1)
            control.sleep(4000)  # zwłoka
        if guest_session_id:
            tmdb_rating_link += "&guest_session_id=%s" % guest_session_id  # link url
        else:
            control.log(f'Problem, bo {guest_session_id=}',1)
            control.idle(2)
            sys.exit()

    url = tmdb_rating_link % tmdb
    # control.log(f'{url=}',1)

    control.busy()
    import xbmcgui
    while True:
        s = xbmcgui.Dialog().input(f"wpisz ocenę TMDB\n(1-10 lub 11-100)", type=xbmcgui.INPUT_NUMERIC)
        if not s or 0 <= int(s) <= 100:
            break
        if not xbmcgui.Dialog().yesno('Niepoprawna wartość', (f"Wpisana wartość [B]{s}[/B] jest nieprawidłowa. \nCzy chcesz poprawić?")):
            s = ''
            break

    if s:
        control.busy()
        # dodatkowy komunikat
        control.infoDialog('proszę czekać ...', 'Ocena dla TMDB', sound=False)
        if not tmdb_sessionid:
            control.log('potrzeba odczekania przed następnym requestem',1)
            control.sleep(5000)  # zwłoka potrzebna
            pass
        else:
            control.sleep(4000)
            pass

        rating = s
        # control.log(f'{rating=}',1)
        rating = int(rating)
        if rating:
            if rating > 10:
                rating = rating / 10
                # rating = round(rating, 1)
                rating = round(rating * 2) / 2  # bo musi być podzielna przez 0.5
            control.log(f'{rating=}',1)

            payload = {"value": rating}
            control.log(f'post',1)
            # control.log(f'post {url=}',1)
            # tmdb_results = requests.post(url, data=payload)  # do serwera
            tmdb_results = requests.post(url, json=payload)  # do serwera
        else:
            payload = ""
            control.log(f'delete',1)
            # control.log(f'delete {url=}',1)
            tmdb_results = requests.delete(url)  # do serwera
    else:
        control.log(f'anulowanie operacji {action=}',1)
        tmdb_results = None

    if tmdb_results is not None:
        icon = ""
        if not tmdb_results:
            if tmdb_results.status_code != 404:
                # control.log(f'wystąpił jakiś problem  {tmdb_results=}  {url=}  {payload=}  {tmdb_results.text=}',1)
                control.log(f'wystąpił jakiś problem  {tmdb_results=}  {payload=}  {tmdb_results.text=}',1)
                icon = "ERROR"
            else:
                icon = "WARNING"
                # control.log(f'być może była nie dawno robiona ocena',1)
                monitor = control.monitor
                counter = 10
                while counter > 0 and tmdb_results.status_code == 404:
                    try:
                        status_code = tmdb_results.json().get("status_code")
                        if status_code not in [34]:  # https://developer.themoviedb.org/docs/errors
                            break
                    except:
                        break
                    counter -= 1
                    control.log(f'czekam przed ponowieniem żądania do serwera  {counter=}',1)
                    control.sleep(5000)
                    if monitor.abortRequested():
                        break
                    if payload:
                        # tmdb_results = requests.post(url, data=payload)
                        tmdb_results = requests.post(url, json=payload)
                    else:
                        tmdb_results = requests.delete(url)
            if tmdb_results:
                icon = ""
            tmdb_results = tmdb_results.json()  # format json, czyli słownik będzie w Pythonie
        control.log(f'{tmdb_results=}  {{tmdb_results.text=}}',1)
        try:
            import json  # dla poniższego tylko
            control.log(f'tmdb_results={json.dumps(tmdb_results, indent=2)}',0)
            pass
        except:
            pass
        # dać komunikat
        control.infoDialog(f'Operacja {("NIE " if icon else "")}wykonana pomyślnie', 'Ocena dla TMDB', sound=True, icon=icon)
    control.idle(2)
    # przydałoby się jeszcze dorobić usunięcie z cache listy ocenionych



elif action == "DeleteList":
    if not (
        control.yesnoDialog(
            "Czy chcesz [B]skasować[/B] listę " + f"\n\n[LIGHT][I]{name}[/I][/LIGHT]",
            yeslabel="Skasuj",
            nolabel="Zostaw",
            heading="Wymagane potwierdzenie",
        )
    ):
        # control.idle(2)
        sys.exit()

    control.busy()
    control.sleep(200)

    # if "self" not in globals():
    if "self" not in locals():
        class self:
            pass

    # self.tmdb_access_token = control.setting("tmdb.access_token") or ""  # musi byc autoryzacja v4
    # self.tm_bearer = control.setting("tm.user_bearer") or apis.tmdb_bearer  # nie wiem, czy to zastąpi session_id
    # control.log(f'{self}',1)
    # control.log(f'{self.tmdb_access_token=}',1)
    # control.log(f'{self.tm_bearer=}',1)
    # bearer = self.tmdb_access_token or self.tm_bearer
    # control.log(f'{bearer=}',1)

    from ptw.libraries import apis
    tm_user = control.setting("tm.user") or apis.tmdb_API
    tmdb_sessionid = control.setting("tmdb.sessionid") or ""
    # self.tm_user = tm_user
    # self.tmdb_sessionid = tmdb_sessionid

    list_id = params.get("id")

    tmdbuserDeleteList_link = "https://api.themoviedb.org/3/list/%%s?api_key=%s&session_id=%s" % (tm_user, tmdb_sessionid)  # delete method
    url = tmdbuserDeleteList_link % list_id

    monitor = control.monitor
    counter = 1

    import requests

    # from resources.lib.indexers import movies
    # import resources.lib.indexers.tmdb_manager  # tylko, że tam robione pod klasę
    from resources.lib.indexers.tmdb_manager import doRequest

    while True:

        tmdb_results = requests.delete(url)
        # tmdb_results = movies.movies().doRequest(url, method="delete")
        # tmdb_results = self.doRequest(url, method="delete")  # to jak w klasie
        # tmdb_results = doRequest(self, url, method="delete")  # tu jest przekazanie dodatkowej zmiennej self imitującej klasę
        # tmdb_results = None  # do testów tylko

        if not tmdb_results and tmdb_results is not None and tmdb_results.status_code == 404:  # tylko, że jak nie ma takiej listy, to ten sam kod daje ich API
            control.log(f'wystąpił jakiś problem  {tmdb_results.text=}  {url=}',1)
            try:
                status_code = tmdb_results.json().get("status_code")
                if status_code not in [34]:  # https://developer.themoviedb.org/docs/errors
                    break
            except:
                break
            counter -= 1
            if counter > 0:
                control.log(f'czekam przed ponowieniem żądania do serwera  {counter=}',1)
                control.sleep(5000)
                if monitor.abortRequested():
                    break
            else:
                break
        else:
            break
    if tmdb_results is not None:
        # control.log(f'{tmdb_results=}  \n{tmdb_results.text=}  \n{url=}',1)
        pass
    else:
        control.log(f'{tmdb_results=}  \n{url=}',1)

    result = tmdb_results
    try:
        msg = result.json()
        try:
            msg = msg.get("status_message") or ""
        except:
            pass
        msg = f'\n[LIGHT][I]{msg}[/I][/LIGHT]' if msg else ""
    except:
        try:
            msg = result.text
        except:
            msg = ""
            pass

    icon = control.infoLabel("ListItem.Icon") if result else "ERROR"  # jak to działa z tym infoLabel("ListItem.Icon") ?
    control.infoDialog(
        ("NIE " if icon == "ERROR" else "") + "wykonano poprawnie" + msg,
        heading="Menadżer TMDB",
        sound=True,
        icon=icon,
    )

    if True:
        from ptw.libraries import cache
        control.log(f'usuwam z cache',1)
        # key = (self.tmdblist, self.tmdb_user_lists)  # tylko, że self.tmdblist do jest funkcja z pliku movies.py albo tvshows.py (chyba, że chodzi tylko o nazwę funkcji)
        # key = ("tmdblist", tmdb_user_lists)  # tylko, że tam jest page=1 zaszyte
        tmdbuser = control.setting("tmdb.username") or "me"  # or control.setting("tmdb.account_id")
        lang = control.apiLanguage()["tmdb"]
        tmdb_user_lists = "https://api.themoviedb.org/3/account/%s/lists?api_key=%s&language=%s&session_id=%s&page=1" % (tmdbuser, tm_user, lang, tmdb_sessionid)
        url = tmdb_user_lists
        import re
        # url = re.sub("((?<=[?/])|&)(page[=/])([^&])", lambda x: x[1]+x[2]+str(int(x[3])+1), url).replace("?&", "?").rstrip("?&")
        url = re.sub("((?<=[?/])|&)(page[=/])([^&])", r"\1\2{}", url).replace("?&", "?").rstrip("?&")
        if "{}" in url:
            for n in range(1,10):  # do ilu jechać ?
                urlN = url.format(n)
                key = ("%.tmdblist", urlN)
                # control.log(f'{key=}',1)
                status = cache.remove(*key, like=True)  # usunięcie z cache
                if status is False:
                    if n == 1:
                        # control.log('usuwam zmienne kluczy z adresu (jeśli są)',1)
                        # url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                        # url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                        # url = url.rstrip("?")
                        # urlN = url.format(n)
                        # key = ("%.tmdblist", urlN)
                        # status = cache_remove(*key, like=True)  # próba usunięcia z cache
                        if status is False:
                            # control.log(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1)
                            break
                    else:
                        # control.log(f'{status=} oznacza, że nie ma więcej stron',1)
                        break  # nie ma sensu próbować kolejnych stron
        else:
            key = ("%.tmdblist", url)
            # control.log(f'{key=}',1)
            status = cache.remove(*key, like=True)  # usunięcie z cache
            if status is False:
                # control.log('usuwam zmienne kluczy z adresu (jeśli są)',1)
                # url = re.sub(r"[&]?\bapi_key=[^&]*", "", url)
                # url = re.sub(r"[&]?\bsession_id=[^&]*", "", url)
                # url = url.rstrip("?")
                # key = ("%.tmdblist", url)
                # status = cache.remove(*key, like=True)  # usunięcie z cache
                if status is False:
                    # control.log(f'{status=} co oznacza, że nie ma cache dla tej funkcji {key=}',1)
                    pass

    control.sleep(200)
    control.idle(2)
    control.sleep(200)
    control.refresh()



elif action == "test":
    """ coś na testy """
    control.log(f'[FanFilm] {action=}',1)
    pass
    # przykład okna
    # from https://kodi.wiki/view/GUI_tutorial
    import xbmcgui
    import sys
    # import urlparse
    from urllib.parse import parse_qs

    class PopupWindow(xbmcgui.WindowDialog):
        # def __init__(self, image, line1, line2, line3, line4, line5):
        def __init__(self, image, line1="tu twój napis", line2="dryga linia", line3="", line4="", line5="", action=""):
        # def __init__(self, **kwargs):
            self.addControl( xbmcgui.ControlImage(x=25, y=25, width=150, height=150, filename=image[0]) )
            self.addControl( xbmcgui.ControlLabel(x=190, y=25, width=500, height=25, label=line1[0]) )
            self.addControl( xbmcgui.ControlLabel(x=190, y=50, width=500, height=25, label=line2[0]) )
            # self.addControl( xbmcgui.ControlLabel(x=190, y=75, width=500, height=25, label=line3[0]) )
            # self.addControl( xbmcgui.ControlLabel(x=190, y=100, width=500, height=25, label=line4[0]) )
            # self.addControl( xbmcgui.ControlLabel(x=190, y=125, width=500, height=25, label=line5[0]) )
            self.addControl( xbmcgui.ControlButton(x=190, y=150, width=500, height=25, label="guzik1") )  # potrzebna jeszcza jakaś akcja
            # control.log(f'{dir(self)=}',1)

    # if __name__ == '__main__':
    if False:
        control.log(f'[FanFilm] {__name__=}',1)
        params1 = parse_qs('&'.join(sys.argv[1:]))
        control.log(f'[FanFilm] {params1=}',1)
    else:
        data_path = control.dataPath
        import os
        qrcode_file = os.path.join(data_path, "qrcode.png")
        params1 = {"image": [qrcode_file], "line1": ["dowolny tekst"]}

    window = PopupWindow(**params1)
    window.show()
    xbmc.sleep(5000)
    # control.directory(handle)
    window.close()
    del window
    # jak wrócić focusem na Container?




control.log(f'[FanFilm][default.py]   koniec {params=}\n', 0)
# control.log(f"============================================================", not(logsilent))

# control.log(f'[FanFilm][default.py]   {action=}', 1)
# control.log(f'[FanFilm][default.py]   {params=}', 1)
# handle = int(sys.argv[1])
# control.log(f'[FanFilm][default.py]   {handle=}', 1)
if (action != "nothing"
    # and params != KFolderPath
     and params != FFlastpath
     and action and "silent" not in action.lower()  # to próba na coś, co się robić będzie w tle (jak synchronizacja biblioteki)
     # and "silent" not in params
     # and handle > -1  # zastanowić się nad tym
   ):
    control.window.setProperty('FanFilm.var.prev_lastpath', repr(FFlastpath))
    control.window.setProperty('FanFilm.var.lastpath', repr(params))  # do pamięci

# try to prevent infinite busydialog
# handle = int(sys.argv[1])  # wyżej to daję
# control.log(f"[FanFilm]  koniec  {sys.argv=}", 1)
# control.log(f"[FanFilm]  koniec  {handle=}  {action=}", 1)
if handle > -1 and action not in ['removeFromSearchHistory', 'clearCacheSearch', 'trailer', 'nothing']:

    c = 3
    while control.condVisibility('Window.IsActive(busydialog)') and c > 0:
        control.sleep0(100)
        c -= 1

    # PluginName = control.infoLabel('Container.PluginName')  # tu można pomyśleć (jak pusty, lub nie 'plugin.video.fanfilm', to oznacza, że wywoływane z innego pluginu)
    # control.log(f"[FanFilm] {PluginName=}", 1)
    # isFolder = control.condVisibility('ListItem.IsFolder')  # nie sprawdza się, bo nie zawsze potrafi odczytać prawidłową pozycję
    # control.log(f"[FanFilm] {isFolder=}", 1)
    # IsPlayable = control.infoLabel('ListItem.Property(IsPlayable)')  # na tym też do końca nie można polegać, bo Kodi czasami tego nie odczytuje prawidłowo
    # control.log(f'[FanFilm] {IsPlayable=}', 1)
    ilosc_pozycji_do_wyswietlenia = control.infoLabel("Container().NumItems")  # często pokazuje informacje przed odświeżeniem, także nieprzydatne wówczas (a jak pokazuje, to czasami jest puste a czasami 0 - i bądź tu mądry)
    # control.log(f'[FanFilm] {ilosc_pozycji_do_wyswietlenia=}', 1)
    # control.log(f"[FanFilm] {control.currentDialogId()=}", 1)  # może być BusyDialog albo ProgressDialog (10101)

    if (
        control.condVisibility('Window.IsActive(busydialog)')  # trafiłem na ProgressDialog przy próbie tworzenia skrótu przez skórkę
        # or (not ilosc_pozycji_do_wyswietlenia or int(ilosc_pozycji_do_wyswietlenia) < 1)  # to pomogło przy próbie tworzenia skrótu przez skórkę
        or not ilosc_pozycji_do_wyswietlenia  # czy to by nie wystarczyło? (zamiast powyższej linijki)
       ):
        if action != "play":  # nie wiem, czy to dobrze !  (jeszcze ewentualnie z select można spróbować dołożyć, bo playItem się nie sprawdził, jak materiał się nie odtworzył
            control.log('[FanFilm] dodanie pustego katalogu', not(logsilent))  # potrzebne tylko, gdy akcja została wywoływana jako folder, a nie wygenerowała żadnej zawartości
            updateListing = True if params.get("r") else False  # True świadczy, że po drodze było odświeżanie
            control.directory(handle, cacheToDisc=True, updateListing=updateListing)  # w Kodi 19 może pojawiś się czasami WARNING w logach (że niepotrzebnie czasami taka operacja), ale w nowszych nie widziałem
            control.sleep0(100)

        if control.currentDialogId() == 9999 and action != "playItem":  # nie pamiętam co oznacza 9999 (może brak jakiegokolwiek okna)
            if action != "play" or select == "1":  # czy zmienna "select" zawsze jest zdefiniowana?
                if not control.monitor.abortRequested():
                    control.log(f"[FanFilm] {sys.argv=}", not(logsilent))
                    if False:  # tymczasowo, jako wybór wariantu
                        # control.log(f"[FanFilm] Can't display content for {sys.argv=}", 1)  # wyniosłem wyżej
                        # control.log(f"------------------------------------------------------------ \n", 1)
                        control.infoDialog(f"Brak zawartości[CR] ERROR    for {action=}", icon="ERROR", time=2000, sound=True)
                        # control.addItem(handle, url=sys.argv[0]+"?action=nothing", listitem=control.item(label="Wystąpił jakiś błąd"), isFolder=False)
                    else:
                        # control.sleep(100)
                        if control.infoLabel('ListItem.Property(IsPlayable)') != 'true':  # nie wiem, czy to ma sens, bo chyba zawsze będzie spełnione
                            ilosc_pozycji_do_wyswietlenia = control.infoLabel("Container().NumItems")
                            # control.log(f'[FanFilm] {ilosc_pozycji_do_wyswietlenia=}', 1)
                            if ilosc_pozycji_do_wyswietlenia and int(ilosc_pozycji_do_wyswietlenia) < 1:  # dodatkowe zabezpieczenie
                                control.log(f"[FanFilm] action Back", not(logsilent))
                                control.execute('Action(Back)')
                # sys.exit()  # nie wiem, czy to jest na końcu potrzebne