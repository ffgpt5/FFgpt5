# -*- coding: utf-8 -*-
import time, threading
import xbmc, xbmcgui

LOG = xbmc.LOGINFO

def log(msg):
    try:
        xbmc.log(f"[FFRF] {msg}", LOG)
    except Exception:
        pass

MON = xbmc.Monitor()
PLAYER = xbmc.Player()
WIN = xbmcgui.Window(10000)

PROP_LAST_PATH = "ffrf.last_ff_path"
PROP_LAST_TS   = "ffrf.last_ff_path_ts"

PLUGIN_ROOT = "plugin://plugin.video.fanfilm/"  # awaryjny powrót

def _now():
    try:
        return int(time.time())
    except Exception:
        return 0

def _setp(k, v):
    try:
        WIN.setProperty(k, str(v))
    except Exception:
        pass

def _getp(k, default=""):
    try:
        v = WIN.getProperty(k)
        return v if v not in (None, "") else default
    except Exception:
        return default

def _is_ff(path: str) -> bool:
    return isinstance(path, str) and path.lower().startswith("plugin://") and "fanfilm" in path.lower()

def _remember_folder():
    """Zapamiętaj ostatni katalog FanFilm (uruchomionego pluginu)."""
    try:
        cur = xbmc.getInfoLabel("Container.FolderPath")
        if _is_ff(cur):
            _setp(PROP_LAST_PATH, cur)
            _setp(PROP_LAST_TS, _now())
    except Exception:
        pass

def _best_target(max_age=1800) -> str:
    """Zwraca ścieżkę do powrotu (zapamiętaną) lub root pluginu jako fallback."""
    path = _getp(PROP_LAST_PATH, "")
    try:
        ts = int(_getp(PROP_LAST_TS, "0"))
    except Exception:
        ts = 0
    if path and _is_ff(path) and (_now() - ts) <= max_age:
        return path
    return PLUGIN_ROOT

def _activate_to(path: str):
    """Wejście do okna Wideo (10025) z podaną ścieżką pluginu oraz dopięcie focusu na liście (id=50)."""
    try:
        xbmc.executebuiltin("Dialog.Close(all,true)")  # pozamykaj zbędne okna po playerze
        xbmc.executebuiltin(f"ActivateWindow(10025,{path},return)")
        # Focus na główny kontener (większość skinów: 50)
        xbmc.executebuiltin("Control.SetFocus(50,0,true)")
        log(f"ActivateWindow -> {path}")
    except Exception as e:
        log(f"ActivateWindow error: {e}")

def _guard_return(duration=7.0, interval=0.25):
    """
    Pętla anty-bounce:
    - zamyka dialogi, wymusza powrót do listy FanFilm (również gdy free -> handle=-1),
    - pilnuje focusu przez kilka sekund (część skinów gubi fokus po odtwarzaniu).
    """
    t_end = time.time() + duration
    target = _best_target()
    fired_once = False

    while time.time() < t_end and not MON.abortRequested():
        cur_folder = xbmc.getInfoLabel("Container.FolderPath")
        cur_win = xbmcgui.getCurrentWindowId()

        if _is_ff(cur_folder):
            if fired_once:
                log("Powrót potwierdzony, koniec strażnika")
            break

        # Jeżeli nie jesteśmy w FanFilm albo wylądowaliśmy na Home (10000) / Videos (10025) bez ścieżki – wymuś wejście.
        if cur_win in (10000, 10025) or not _is_ff(cur_folder):
            _activate_to(target)
            fired_once = True

        time.sleep(interval)

class GuardPlayer(xbmc.Player):
    def onPlayBackStopped(self):
        log("onPlayBackStopped")
        threading.Thread(target=_guard_return, daemon=True).start()

    def onPlayBackEnded(self):
        log("onPlayBackEnded")
        threading.Thread(target=_guard_return, daemon=True).start()

_g = GuardPlayer()

log("Service start 1.4.0")
while not MON.abortRequested():
    try:
        _remember_folder()
    except Exception:
        pass
    if MON.waitForAbort(0.3):
        break
log("Service stop")
